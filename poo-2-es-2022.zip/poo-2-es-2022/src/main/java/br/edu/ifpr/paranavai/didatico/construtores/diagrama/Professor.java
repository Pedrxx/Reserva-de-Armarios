package br.edu.ifpr.paranavai.construtores.diagrama;

public class Professor {
    // atributos

    String nome;

    public Professor() {
        super();
    }

    public Professor(String nome) {
        super();
        this.nome = nome;
    }

}
