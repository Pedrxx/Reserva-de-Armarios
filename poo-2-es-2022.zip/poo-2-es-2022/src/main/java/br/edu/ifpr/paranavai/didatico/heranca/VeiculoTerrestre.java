package br.edu.ifpr.paranavai.heranca;

public class VeiculoTerrestre extends Veiculo {

    private String placa;
    private String renavam;

    public VeiculoTerrestre() {
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public String getRenavam() {
        return renavam;
    }

    public void setRenavam(String renavam) {
        this.renavam = renavam;
    }

}
