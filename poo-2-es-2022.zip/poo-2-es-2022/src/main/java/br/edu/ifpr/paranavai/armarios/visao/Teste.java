package br.edu.ifpr.paranavai.armarios.visao;

import br.edu.ifpr.paranavai.armarios.modelo.Bibliotecario;

public class Teste {

    public static void main(String[] args) {
        Bibliotecario bibliotecario = new Bibliotecario();
    }
}
