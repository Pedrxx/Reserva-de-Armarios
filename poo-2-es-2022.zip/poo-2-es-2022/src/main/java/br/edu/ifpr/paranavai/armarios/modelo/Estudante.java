package br.edu.ifpr.paranavai.armarios.modelo;

public class Estudante extends Pessoa {

    private String ra;
}
