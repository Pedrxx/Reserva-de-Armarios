package br.edu.ifpr.paranavai.heranca;

public class VeiculoAquatico extends Veiculo {

    private int numeroDeRegistro;

    public int getNumeroDeRegistro() {
        return numeroDeRegistro;
    }

    public void setNumeroDeRegistro(int numeroDeRegistro) {
        this.numeroDeRegistro = numeroDeRegistro;
    }

}
