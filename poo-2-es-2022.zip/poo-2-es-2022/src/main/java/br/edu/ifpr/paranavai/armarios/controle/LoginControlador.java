/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.ifpr.paranavai.armarios.controle;

/**
 *
 * @author Aluno
 */
public class LoginControlador {
    
    public String verifica(String email, String senha) {
        return "Sucesso no login";
    }
    
}
