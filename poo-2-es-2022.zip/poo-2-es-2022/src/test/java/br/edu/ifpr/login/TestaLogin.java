package br.edu.ifpr.login;

import br.edu.ifpr.paranavai.armarios.controle.LoginControlador;
import org.junit.Test;

public class TestaLogin {
    @Test
    public void autenticaOk() {
        String email = "Email@gmail.com";
        String senha = "1234";
        LoginControlador controle = new LoginControlador();
        String resposta = controle.verifica(email, senha);
        Assert.assertEquals("Sucesso no login", resposta);
                
        
    }
}
